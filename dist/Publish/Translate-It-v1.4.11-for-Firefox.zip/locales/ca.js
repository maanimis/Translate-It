const a="Catalan",e="ca-ES",c="Catalan",o="ca",t={name:a,voiceCode:e,promptName:c,code:"ca"};export{o as code,t as default,a as name,c as promptName,e as voiceCode};
