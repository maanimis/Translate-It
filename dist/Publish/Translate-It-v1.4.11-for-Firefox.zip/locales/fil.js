const i="Filipino",o="fil-PH",e="Filipino",p="fi",a={name:i,voiceCode:o,promptName:e,code:"fi"};export{p as code,a as default,i as name,e as promptName,o as voiceCode};
