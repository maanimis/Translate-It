const e="Slovenian",o="sl-SI",a="Slovenian",l="sl",n={name:e,voiceCode:o,promptName:a,code:"sl"};export{l as code,n as default,e as name,a as promptName,o as voiceCode};
