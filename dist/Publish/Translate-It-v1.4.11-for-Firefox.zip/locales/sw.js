const e="Swahili",a="sw-KE",o="Swahili",i="sw",s={name:e,voiceCode:a,promptName:o,code:"sw"};export{i as code,s as default,e as name,o as promptName,a as voiceCode};
