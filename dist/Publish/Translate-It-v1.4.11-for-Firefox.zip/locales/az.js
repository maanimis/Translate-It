const a="Azerbaijani",e="az-AZ",o="Azerbaijani",i="az",z={name:a,voiceCode:e,promptName:o,code:"az"};export{i as code,z as default,a as name,o as promptName,e as voiceCode};
