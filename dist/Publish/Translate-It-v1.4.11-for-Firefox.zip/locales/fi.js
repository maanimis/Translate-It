const i="Finnish",e="fi-FI",n="Finnish",o="fi",a={name:i,voiceCode:e,promptName:n,code:"fi"};export{o as code,a as default,i as name,n as promptName,e as voiceCode};
