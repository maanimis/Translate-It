const a="Punjabi",e="pa-IN",o="Punjabi",p="pa",n={name:a,voiceCode:e,promptName:o,code:"pa"};export{p as code,n as default,a as name,o as promptName,e as voiceCode};
