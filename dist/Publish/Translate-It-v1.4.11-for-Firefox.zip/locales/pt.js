const e="Portuguese",t="pt-PT",o="Portuguese",p="pt",u={name:e,voiceCode:t,promptName:o,code:"pt"};export{p as code,u as default,e as name,o as promptName,t as voiceCode};
