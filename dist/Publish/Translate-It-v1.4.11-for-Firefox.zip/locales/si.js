const a="Sinhala",e="si-LK",i="Sinhala",o="si",s={name:a,voiceCode:e,promptName:i,code:"si"};export{o as code,s as default,a as name,i as promptName,e as voiceCode};
