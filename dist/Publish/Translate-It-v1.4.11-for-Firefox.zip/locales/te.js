const e="Telugu",t="te-IN",o="Telugu",u="te",a={name:e,voiceCode:t,promptName:o,code:"te"};export{u as code,a as default,e as name,o as promptName,t as voiceCode};
