const a="Tamil",e="ta-IN",t="Tamil",o="ta",m={name:a,voiceCode:e,promptName:t,code:"ta"};export{o as code,m as default,a as name,t as promptName,e as voiceCode};
