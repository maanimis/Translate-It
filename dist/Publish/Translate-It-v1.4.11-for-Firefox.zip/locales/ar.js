const a="Arabic",e="ar-SA",r="Arabic",o="ar",c={name:a,voiceCode:e,promptName:r,code:"ar"};export{o as code,c as default,a as name,r as promptName,e as voiceCode};
