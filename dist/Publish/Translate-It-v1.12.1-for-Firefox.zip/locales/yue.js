const e="Cantonese",a="粵語",n="Cantonese",t="yue",o={name:e,nativeName:"粵語",promptName:n,code:"yue"};export{t as code,o as default,e as name,a as nativeName,n as promptName};
