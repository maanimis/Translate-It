const t="Lithuanian",a="lt-LT",e="Lithuanian",n="lt",o={name:t,voiceCode:a,promptName:e,code:"lt"};export{n as code,o as default,t as name,e as promptName,a as voiceCode};
