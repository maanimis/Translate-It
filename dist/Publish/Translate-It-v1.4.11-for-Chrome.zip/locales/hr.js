const a="Croatian",o="hr-HR",e="Croatian",r="hr",t={name:a,voiceCode:o,promptName:e,code:"hr"};export{r as code,t as default,a as name,e as promptName,o as voiceCode};
