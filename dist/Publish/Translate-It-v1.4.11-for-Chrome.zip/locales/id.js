const e="Indonesian",d="id-ID",n="Indonesian",o="id",a={name:e,voiceCode:d,promptName:n,code:"id"};export{o as code,a as default,e as name,n as promptName,d as voiceCode};
