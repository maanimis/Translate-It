const e="Spanish",s="es-ES",a="Spanish",o="es",p={name:e,voiceCode:s,promptName:a,code:"es"};export{o as code,p as default,e as name,a as promptName,s as voiceCode};
