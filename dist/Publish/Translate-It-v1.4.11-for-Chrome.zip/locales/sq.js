const a="Albanian",e="sq-AL",n="Albanian",o="sq",s={name:a,voiceCode:e,promptName:n,code:"sq"};export{o as code,s as default,a as name,n as promptName,e as voiceCode};
