const o="Norwegian",e="no-NO",n="Norwegian",a="no",r={name:o,voiceCode:e,promptName:n,code:"no"};export{a as code,r as default,o as name,n as promptName,e as voiceCode};
