const a="Kazakh",k="kk-KZ",e="Kazakh",o="kk",t={name:a,voiceCode:k,promptName:e,code:"kk"};export{o as code,t as default,a as name,e as promptName,k as voiceCode};
