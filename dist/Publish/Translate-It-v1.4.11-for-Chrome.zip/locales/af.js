const a="Afrikaans",e="af-ZA",f="Afrikaans",o="af",n={name:a,voiceCode:e,promptName:f,code:"af"};export{o as code,n as default,a as name,f as promptName,e as voiceCode};
