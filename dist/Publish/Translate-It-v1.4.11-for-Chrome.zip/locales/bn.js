const e="Bengali",n="bn-BD",a="Bengali",o="bn",t={name:e,voiceCode:n,promptName:a,code:"bn"};export{o as code,t as default,e as name,a as promptName,n as voiceCode};
