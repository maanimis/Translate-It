const e="Estonian",t="et-EE",o="Estonian",a="et",n={name:e,voiceCode:t,promptName:o,code:"et"};export{a as code,n as default,e as name,o as promptName,t as voiceCode};
