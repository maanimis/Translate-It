const e="Hebrew",o="he-IL",a="Hebrew",r="he",t={name:e,voiceCode:o,promptName:a,code:"he"};export{r as code,t as default,e as name,a as promptName,o as voiceCode};
