const e="German",a="de-DE",d="German",o="de",m={name:e,voiceCode:a,promptName:d,code:"de"};export{o as code,m as default,e as name,d as promptName,a as voiceCode};
