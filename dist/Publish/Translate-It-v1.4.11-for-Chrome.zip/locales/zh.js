const e="Chinese (Simplified)",i="zh-CN",o="Chinese (Simplified)",d="zh",h={name:e,voiceCode:i,promptName:o,code:"zh"};export{d as code,h as default,e as name,o as promptName,i as voiceCode};
