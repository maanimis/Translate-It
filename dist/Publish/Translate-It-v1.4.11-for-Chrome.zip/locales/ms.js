const a="Malay",e="ms-MY",m="Malay",o="ms",s={name:a,voiceCode:e,promptName:m,code:"ms"};export{o as code,s as default,a as name,m as promptName,e as voiceCode};
