const a="Hungarian",e="hu-HU",n="Hungarian",o="hu",u={name:a,voiceCode:e,promptName:n,code:"hu"};export{o as code,u as default,a as name,n as promptName,e as voiceCode};
