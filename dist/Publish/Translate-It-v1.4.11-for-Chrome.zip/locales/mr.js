const a="Marathi",e="mr-IN",r="Marathi",m="mr",o={name:a,voiceCode:e,promptName:r,code:"mr"};export{m as code,o as default,a as name,r as promptName,e as voiceCode};
