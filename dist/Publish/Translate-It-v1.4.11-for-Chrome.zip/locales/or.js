const o="Odia",e="or-IN",a="Odia",d="or",r={name:o,voiceCode:e,promptName:a,code:"or"};export{d as code,r as default,o as name,a as promptName,e as voiceCode};
