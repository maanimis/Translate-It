const e="Nepali",a="ne-NP",o="Nepali",n="ne",p={name:e,voiceCode:a,promptName:o,code:"ne"};export{n as code,p as default,e as name,o as promptName,a as voiceCode};
