const t="Italian",a="it-IT",e="Italian",i="it",o={name:t,voiceCode:a,promptName:e,code:"it"};export{i as code,o as default,t as name,e as promptName,a as voiceCode};
